My original floppy disk is apparently corrupted, and these three files: damage.e, display.e, and sched.e, could not be copied.
